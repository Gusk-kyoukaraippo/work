window.__EXCEL_GATE_TIMING__=null;
