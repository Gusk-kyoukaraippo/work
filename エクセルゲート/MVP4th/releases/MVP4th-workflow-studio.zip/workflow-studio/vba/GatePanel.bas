Attribute VB_Name = "GatePanel"
Option Explicit

Public Sub InitializeGate()
    On Error GoTo InitializeFailed
    If ThisWorkbook.ReadOnly Then Err.Raise vbObjectError + 2400, , "����Excel�͓ǂݎ���p�ł��B"
    If Len(ThisWorkbook.Path) = 0 Then Err.Raise vbObjectError + 2401, , "���Excel�t�@�C�������L�t�H���_�֕ۑ����Ă��������B"
    GateValidateDeployment

    If GateWorkbookIsInitialized() Then
        Err.Raise vbObjectError + 2402, , "�������ς݂ł��B�f�[�^�ی�̂��ߍď������ł��܂���B"
    End If

    Application.ScreenUpdating = False
    On Error Resume Next
    ThisWorkbook.Unprotect GATE_PROTECT_PASSWORD
    Dim existingSheet As Object
    For Each existingSheet In ThisWorkbook.Worksheets
        existingSheet.Unprotect GATE_PROTECT_PASSWORD
    Next existingSheet
    On Error GoTo InitializeFailed
    GateEnsureInternalSheets
    GateBuildOperationPanel
    GateEnsureFolder GateProjectPath(GATE_ACCEPTED_RELATIVE)
    GateEnsureFolder GateProjectPath(GATE_REJECTED_RELATIVE)
    GateEnsureFolder GateProjectPath(GATE_PENDING_RELATIVE)
    GateEnsureFolder GateProjectPath(GATE_SESSIONS_RELATIVE)

    If Len(gWorkbookRunId) = 0 Then gWorkbookRunId = GateNewId()
    GateApplyProtection
    RefreshOperationPanel
    GateSaveWorkbook "initialize"
    Application.ScreenUpdating = True
    MsgBox "Excel�Q�[�g MVP4�̑���p�l�����쐬���܂����B" & vbCrLf & _
           "���p�҂Ɍ�����V�[�g�́u����p�l���v�����ł��B", vbInformation, "Excel�Q�[�g MVP4"
    GateScheduleTimer
    Exit Sub

InitializeFailed:
    Application.ScreenUpdating = True
    MsgBox "Excel�Q�[�g MVP4���������ł��܂���ł����B" & vbCrLf & vbCrLf & Err.Description, vbExclamation, "Excel�Q�[�g MVP4"
End Sub

Private Sub GateBuildOperationPanel()
    Dim ws As Object
    Set ws = ThisWorkbook.Worksheets(GATE_PANEL_SHEET)
    ws.Visible = -1
    On Error Resume Next
    ws.Unprotect GATE_PROTECT_PASSWORD
    ws.Cells.UnMerge
    ws.Cells.Clear
    Dim shape As Object
    For Each shape In ws.Shapes
        shape.Delete
    Next shape
    On Error GoTo 0

    ws.Cells.Font.Name = "Yu Gothic UI"
    ws.Cells.Font.Size = 11
    ws.Columns("A").ColumnWidth = 3
    ws.Columns("B:N").ColumnWidth = 10
    ws.Columns("O").ColumnWidth = 3
    ws.Rows("1:46").RowHeight = 24
    ws.Rows(2).RowHeight = 34
    ws.Rows(3).RowHeight = 25
    ws.Rows("4:6").RowHeight = 31
    ws.Rows(7).RowHeight = 22

    ws.Range("B2:N2").Merge
    ws.Range("B2").Value2 = "Excel�Q�[�g MVP4  �󂯓n���E�����ۑ�"
    With ws.Range("B2:N2")
        .Font.Size = 22
        .Font.Bold = True
        .Font.Color = RGB(23, 50, 77)
        .HorizontalAlignment = -4131
        .VerticalAlignment = -4108
    End With

    ws.Range("B3:N3").Merge
    With ws.Range("B3:N3")
        .Value2 = ""
        .Font.Size = 11
        .Font.Bold = True
        .HorizontalAlignment = -4108
        .VerticalAlignment = -4108
        .Interior.Color = RGB(247, 249, 251)
    End With

    GateFormatStatusAreas ws

    GateAddButton ws, "�g�������J��", "OpenGateHelp", ws.Range("B8:N9"), RGB(23, 107, 91)

    GateFormatCard ws.Range("B10:N15"), "�����ۑ��F�ŐV��"

    ws.Range("B18:N18").Merge
    ws.Range("B18").Value2 = "�ʏ�̑���i�ォ�珇�ɐi�݂܂��j"
    ws.Range("B18").Font.Bold = True
    ws.Range("B18").Font.Size = 14
    ws.Range("B18").Font.Color = RGB(23, 50, 77)

    GateAddButton ws, "�{������", "OpenReadOnlyHtml", ws.Range("B20:G22"), RGB(91, 116, 139)
    GateAddButton ws, "�ҏW����", "OpenEditHtml", ws.Range("H20:N22"), RGB(23, 105, 170)
    GateAddButton ws, "�󂯓n���t�@�C���𐳎��ۑ�����", "ImportSaveData", ws.Range("B24:N26"), RGB(20, 122, 85)
    GateAddButton ws, "�I������", "ExitWorkbook", ws.Range("B28:N30"), RGB(74, 86, 99)

    GateFormatGuidanceArea ws

    GateFormatAdminArea ws
    GateAddButton ws, "���O�`�F�b�N�i�Ǘ��Ҍ����j", "OpenSaveHistory", ws.Range("B42:F44"), RGB(91, 116, 139)

    ws.Cells.Locked = True
    ws.Activate
    ActiveWindow.DisplayGridlines = False
    ActiveWindow.Zoom = 90
End Sub

Private Sub GateFormatStatusAreas(ByVal ws As Object)
    On Error Resume Next
    ws.Range("B4:N7").UnMerge
    On Error GoTo 0
    ws.Range("B4:N6").Merge
    ws.Range("B7:N7").Merge

    With ws.Range("B4:N6")
        .WrapText = True
        .Font.Size = 13
        .Font.Bold = True
        .VerticalAlignment = -4108
        .HorizontalAlignment = -4131
        .IndentLevel = 1
        .Borders.LineStyle = 1
        .Borders.Weight = 2
    End With

    With ws.Range("B7:N7")
        .WrapText = False
        .Font.Size = 9
        .Font.Bold = False
        .Font.Color = RGB(82, 103, 122)
        .Interior.Color = RGB(247, 249, 251)
        .HorizontalAlignment = -4131
        .VerticalAlignment = -4108
        .IndentLevel = 1
        .Borders.LineStyle = 0
    End With
End Sub

Private Sub GateFormatGuidanceArea(ByVal ws As Object)
    On Error Resume Next
    ws.Range("B33").MergeArea.UnMerge
    On Error GoTo 0
    ws.Range("B33:N37").Merge

    Dim usageText As String
    If ThisWorkbook.ReadOnly Then
        usageText = "����Excel�ł̓f�[�^�̓��́E�ҏW�E�����ۑ��͂ł��܂���B�ʏ�̗��p�҂́u�{������v�𗘗p���Ă��������B�u���O�`�F�b�N�i�Ǘ��Ҍ����j�v�̑���͕s�v�ł��B"
    Else
        usageText = "������f�[�^�͂���Excel�֒��ړ��͂��܂���B�ҏW�́u�ҏW����v����HTML�ōs���A�Ō�Ɂu�󂯓n���t�@�C���𐳎��ۑ�����v�������Ă��������B"
    End If
    ws.Range("B33").Value2 = usageText & vbLf & vbLf & _
                              "PC�́u�_�E�����[�h�v�ɂ͎󂯓n���t�@�C���iJSON�j���c��܂��BExcel�Ɂu�����ۑ��͊������Ă��܂��v�ƕ\�����ꂽ��A�t�@�C�����́u�폜�ڈ��v���߂����uExcel�Q�[�g�󂯓n��_�`.json�v�����𐮗����Ă��������B"
    With ws.Range("B33:N37")
        .WrapText = True
        .Font.Size = 10
        .Font.Color = RGB(82, 103, 122)
        .Interior.Color = RGB(242, 246, 249)
        .Borders.LineStyle = 1
        .Borders.Color = RGB(215, 224, 232)
        .VerticalAlignment = -4108
        .IndentLevel = 1
    End With
End Sub

Private Sub GateFormatAdminArea(ByVal ws As Object)
    On Error Resume Next
    ws.Range("B40").MergeArea.UnMerge
    On Error GoTo 0
    ws.Range("B40:N40").Merge
    ws.Range("B40").Value2 = "�Ǘ��җp�i�ʏ�̗��p�҂͑���s�v�j"
    With ws.Range("B40:N40")
        .Font.Size = 10
        .Font.Bold = True
        .Font.Color = RGB(91, 116, 139)
        .HorizontalAlignment = -4131
        .VerticalAlignment = -4108
    End With
End Sub

Private Sub GateFormatCard(ByVal cardRange As Object, ByVal title As String)
    Dim firstColumn As Long
    Dim lastColumn As Long
    firstColumn = cardRange.Column
    lastColumn = cardRange.Column + cardRange.Columns.Count - 1
    Dim ws As Object
    Set ws = cardRange.Worksheet
    ws.Range(ws.Cells(cardRange.Row, firstColumn), ws.Cells(cardRange.Row, lastColumn)).Merge
    ws.Cells(cardRange.Row, firstColumn).Value2 = title
    ws.Range(ws.Cells(cardRange.Row + 1, firstColumn), ws.Cells(cardRange.Row + 5, lastColumn)).Merge
    With cardRange
        .Borders.LineStyle = 1
        .Borders.Color = RGB(204, 215, 224)
        .Interior.Color = RGB(255, 255, 255)
    End With
    With ws.Cells(cardRange.Row, firstColumn)
        .Font.Bold = True
        .Font.Size = 13
        .Font.Color = RGB(23, 50, 77)
        .Interior.Color = RGB(237, 244, 250)
        .HorizontalAlignment = -4108
        .VerticalAlignment = -4108
    End With
    With ws.Cells(cardRange.Row + 1, firstColumn)
        .WrapText = True
        .Font.Size = 12
        .VerticalAlignment = -4108
        .HorizontalAlignment = -4131
        .IndentLevel = 1
    End With
End Sub

Private Sub GateAddButton(ByVal ws As Object, ByVal caption As String, ByVal macroName As String, ByVal targetRange As Object, ByVal fillColor As Long)
    Dim button As Object
    Dim captionFontSize As Long
    captionFontSize = IIf(Len(caption) > 14, 10, 11)
    Set button = ws.Shapes.AddShape(5, targetRange.Left, targetRange.Top, targetRange.Width, targetRange.Height)
    button.Name = "gate_" & macroName
    button.OnAction = "'" & ThisWorkbook.Name & "'!" & macroName
    button.Fill.ForeColor.RGB = fillColor
    button.Line.Visible = 0
    On Error Resume Next
    button.TextFrame2.TextRange.Text = caption
    button.TextFrame2.TextRange.Font.Name = "Yu Gothic UI"
    button.TextFrame2.TextRange.Font.Size = captionFontSize
    button.TextFrame2.TextRange.Font.Bold = True
    button.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
    button.TextFrame2.VerticalAnchor = 3
    button.TextFrame2.TextRange.ParagraphFormat.Alignment = 2
    If Err.Number <> 0 Then
        Err.Clear
        button.TextFrame.Characters.Text = caption
        button.TextFrame.Characters.Font.Color = RGB(255, 255, 255)
        button.TextFrame.Characters.Font.Bold = True
        button.TextFrame.Characters.Font.Size = captionFontSize
    End If
    On Error GoTo 0
End Sub

Public Sub GateApplyProtection()
    If Not GateWorkbookIsInitialized() Then Exit Sub
    Dim wasSaved As Boolean
    wasSaved = ThisWorkbook.Saved
    On Error Resume Next
    ThisWorkbook.Unprotect GATE_PROTECT_PASSWORD
    Dim ws As Object
    For Each ws In ThisWorkbook.Worksheets
        ws.Unprotect GATE_PROTECT_PASSWORD
        If ws.Name = GATE_PANEL_SHEET Then
            ws.Visible = -1
            ws.Protect Password:=GATE_PROTECT_PASSWORD, DrawingObjects:=False, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
        Else
            ws.Visible = 2
            ws.Protect Password:=GATE_PROTECT_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
        End If
    Next ws
    ThisWorkbook.Protect Password:=GATE_PROTECT_PASSWORD, Structure:=True, Windows:=False
    ThisWorkbook.Saved = wasSaved
    On Error GoTo 0
End Sub

Public Sub RefreshOperationPanel()
    If Not GateWorkbookIsInitialized() Then Exit Sub
    Dim wasSaved As Boolean
    wasSaved = ThisWorkbook.Saved
    On Error GoTo RefreshFailed
    Dim ws As Object
    Set ws = ThisWorkbook.Worksheets(GATE_PANEL_SHEET)
    ws.Unprotect GATE_PROTECT_PASSWORD
    GateEnsureOperationPanelLayout ws

    Dim statusText As String
    Dim statusDetail As String
    Dim statusColor As Long
    Dim activeSession As String
    activeSession = GateMetaGet("activeSessionId")
    Dim nowValue As Date
    nowValue = Now
    Dim lastSaveText As String
    lastSaveText = GateMetaGet("lastSaveAt")
    Dim lastSaveValue As Date
    Dim hasLastSaveValue As Boolean
    hasLastSaveValue = GateTryDateTime(lastSaveText, lastSaveValue)

    If GateMetaGet("commitState", "NONE") = "PREPARED" Then
        statusColor = RGB(255, 245, 204)
        statusText = "�����ۑ����������ł�" & vbLf & _
                     "���̐����f�[�^�ƍĊJ����ێ����Ă��܂��B" & vbLf & _
                     "�ڑ����m�F���u�󂯓n���t�@�C���𐳎��ۑ�����v���Ď��s���Ă��������B"
    ElseIf Len(activeSession) > 0 Then
        statusColor = RGB(237, 244, 250)
        Dim startedText As String
        Dim activeGuidance As String
        startedText = GateMetaGet("sessionStartedAt")
        If ThisWorkbook.ReadOnly Then
            activeGuidance = "����Excel�ł͉{�������ł��܂��B��ƒ��̓��e�͕ύX�ł��܂���B"
        Else
            activeGuidance = "��Ƃ��I����ꍇ�́AHTML�Łu�o�͂���Excel�֖߂�v�������A�u�󂯓n���t�@�C���𐳎��ۑ�����v�������Ă��������B"
        End If
        statusText = "HTML�ł̕ҏW��Ƃ�����܂�" & vbLf & _
                     "�ҏW��ʂ��J���������F" & GateDisplayDateTime(startedText) & vbLf & _
                     activeGuidance
        statusDetail = "�Q�l�F�ҏW�J�n���� " & GateElapsedText(startedText, nowValue)
        If Len(lastSaveText) > 0 Then
            statusDetail = statusDetail & " �^ �O��̐����ۑ����� " & GateElapsedText(lastSaveText, nowValue)
        Else
            statusDetail = statusDetail & " �^ �����ۑ��̋L�^�Ȃ�"
        End If
    ElseIf Len(lastSaveText) = 0 Then
        statusColor = RGB(255, 245, 204)
        If ThisWorkbook.ReadOnly Then
            statusText = "�����ۑ��̋L�^�͂���܂���" & vbLf & vbLf & "����Excel�ł͉{�������ł��܂��B"
        Else
            statusText = "�����ۑ��̋L�^�͂���܂���" & vbLf & vbLf & "�u�ҏW����v�����Ƃ��n�߂Ă��������B"
        End If
    ElseIf hasLastSaveValue And nowValue < lastSaveValue Then
        statusColor = RGB(255, 245, 204)
        statusText = "PC�̎������A�Ō�̐����ۑ����O�ɂȂ��Ă��܂�" & vbLf & _
                     "�ŏI�����ۑ��F" & GateDisplayDateTime(lastSaveText) & " �^ �ۑ��ҁF" & GateMetaGet("lastSaveAuthor") & "����" & vbLf & _
                     "PC�̓����ݒ���m�F���Ă��������B"
    Else
        statusColor = RGB(224, 245, 234)
        statusText = "�����ۑ��͊������Ă��܂��BExcel�����Ǝ��̐l���ҏW�ł��܂�" & vbLf & vbLf & _
                     "�ŏI�����ۑ��F" & GateDisplayDateTime(lastSaveText) & vbLf & _
                     "�ۑ��ҁ@�F" & GateMetaGet("lastSaveAuthor") & "����"
        If hasLastSaveValue Then statusDetail = "�Q�l�F�O��̐����ۑ����� " & GateElapsedText(lastSaveText, nowValue)
    End If

    ws.Range("B4").Value2 = statusText
    ws.Range("B7").Value2 = statusDetail
    ws.Range("B4:N6").Interior.Color = statusColor
    ws.Range("B4:N6").Font.Color = RGB(23, 50, 77)
    ws.Range("B4:N6").Borders.Color = RGB(204, 215, 224)

    GateUpdateLatestCard ws.Range("B11")
    GateUpdateReadOnlyControls ws
    ws.Protect Password:=GATE_PROTECT_PASSWORD, DrawingObjects:=False, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
    ThisWorkbook.Saved = wasSaved
    Exit Sub

RefreshFailed:
    On Error Resume Next
    ws.Protect Password:=GATE_PROTECT_PASSWORD, DrawingObjects:=False, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
    ThisWorkbook.Saved = wasSaved
    On Error GoTo 0
End Sub

Private Sub GateEnsureOperationPanelLayout(ByVal ws As Object)
    Dim needsCellLayout As Boolean
    needsCellLayout = (ws.Range("B4").MergeArea.Rows.Count <> 3 Or _
                       ws.Range("B10").MergeArea.Columns.Count <> 13 Or _
                       ws.Range("B33").MergeArea.Rows.Count <> 5)

    If needsCellLayout Then
        On Error Resume Next
        ws.Range("B4:N7").UnMerge
        ws.Range("B10:N15").UnMerge
        ws.Range("B18:N45").UnMerge
        ws.Range("B4:N7").ClearContents
        ws.Range("B10:N15").ClearContents
        ws.Range("B18:N45").ClearContents
        ws.Range("B18:N45").Interior.Color = RGB(247, 249, 251)
        ws.Range("B18:N45").Borders.LineStyle = 0
        On Error GoTo 0

        ws.Rows("1:46").RowHeight = 24
        ws.Rows(2).RowHeight = 34
        ws.Rows(3).RowHeight = 25
        ws.Rows("4:6").RowHeight = 31
        ws.Rows(7).RowHeight = 22

        GateFormatStatusAreas ws
        GateFormatCard ws.Range("B10:N15"), "�����ۑ��F�ŐV��"

        ws.Range("B18:N18").Merge
        ws.Range("B18").Font.Bold = True
        ws.Range("B18").Font.Size = 14
        ws.Range("B18").Font.Color = RGB(23, 50, 77)

        GateFormatGuidanceArea ws
        GateFormatAdminArea ws
    End If

    ws.Range("B2").Value2 = "Excel�Q�[�g MVP4  �󂯓n���E�����ۑ�"
    ws.Range("B10").Value2 = "�����ۑ��F�ŐV��"
    ws.Range("B18").Value2 = "�ʏ�̑���i�ォ�珇�ɐi�݂܂��j"
    ws.Range("B40").Value2 = "�Ǘ��җp�i�ʏ�̗��p�҂͑���s�v�j"

    GateEnsureButton ws, "�g�������J��", "OpenGateHelp", ws.Range("B8:N9"), RGB(23, 107, 91)
    GateMoveButton ws, "OpenGateHelp", ws.Range("B8:N9")
    GateMoveButton ws, "OpenReadOnlyHtml", ws.Range("B20:G22")
    GateMoveButton ws, "OpenEditHtml", ws.Range("H20:N22")
    GateMoveButton ws, "ImportSaveData", ws.Range("B24:N26")
    GateMoveButton ws, "ExitWorkbook", ws.Range("B28:N30")
    GateMoveButton ws, "OpenSaveHistory", ws.Range("B42:F44")
End Sub

Private Sub GateUpdateReadOnlyControls(ByVal ws As Object)
    Dim readOnlyMode As Boolean
    readOnlyMode = ThisWorkbook.ReadOnly

    GateSetButtonCaption ws, "ImportSaveData", "�󂯓n���t�@�C���𐳎��ۑ�����"
    GateSetButtonCaption ws, "OpenSaveHistory", "���O�`�F�b�N�i�Ǘ��Ҍ����j"
    GateSetButtonCaption ws, "OpenGateHelp", "�g�������J��"

    With ws.Range("B3:N3")
        If readOnlyMode Then
            .Value2 = "����Excel�͓ǂݎ���p�ŊJ���Ă��܂��B�{���̂ݗ��p�ł��܂��B"
            .Interior.Color = RGB(91, 116, 139)
            .Font.Color = RGB(255, 255, 255)
            .Borders.LineStyle = 1
            .Borders.Color = RGB(72, 92, 110)
        Else
            .Value2 = ""
            .Interior.Color = RGB(247, 249, 251)
            .Font.Color = RGB(23, 50, 77)
            .Borders.LineStyle = 0
        End If
    End With

    GateFormatGuidanceArea ws

    GateSetButtonEnabled ws, "OpenGateHelp", True, RGB(23, 107, 91)
    GateSetButtonEnabled ws, "OpenReadOnlyHtml", True, RGB(91, 116, 139)
    GateSetButtonEnabled ws, "OpenEditHtml", Not readOnlyMode, RGB(23, 105, 170)
    GateSetButtonEnabled ws, "ImportSaveData", Not readOnlyMode, RGB(20, 122, 85)
    GateSetButtonEnabled ws, "OpenSaveHistory", True, RGB(91, 116, 139)
    GateSetButtonEnabled ws, "ExitWorkbook", True, RGB(74, 86, 99)
End Sub

Private Sub GateEnsureButton(ByVal ws As Object, ByVal caption As String, ByVal macroName As String, ByVal targetRange As Object, ByVal fillColor As Long)
    On Error Resume Next
    Dim button As Object
    Set button = ws.Shapes("gate_" & macroName)
    On Error GoTo 0
    If button Is Nothing Then GateAddButton ws, caption, macroName, targetRange, fillColor
End Sub

Private Sub GateMoveButton(ByVal ws As Object, ByVal macroName As String, ByVal targetRange As Object)
    On Error Resume Next
    Dim button As Object
    Set button = ws.Shapes("gate_" & macroName)
    If button Is Nothing Then Exit Sub

    button.Left = targetRange.Left
    button.Top = targetRange.Top
    button.Width = targetRange.Width
    button.Height = targetRange.Height
    On Error GoTo 0
End Sub

Private Sub GateSetButtonCaption(ByVal ws As Object, ByVal macroName As String, ByVal caption As String)
    On Error Resume Next
    Dim button As Object
    Dim captionFontSize As Long
    captionFontSize = IIf(Len(caption) > 14, 10, 11)
    Set button = ws.Shapes("gate_" & macroName)
    If button Is Nothing Then Exit Sub

    button.TextFrame2.TextRange.Text = caption
    button.TextFrame2.TextRange.Font.Size = captionFontSize
    If Err.Number <> 0 Then
        Err.Clear
        button.TextFrame.Characters.Text = caption
        button.TextFrame.Characters.Font.Size = captionFontSize
    End If
    On Error GoTo 0
End Sub

Private Sub GateSetButtonEnabled(ByVal ws As Object, ByVal macroName As String, ByVal isEnabled As Boolean, ByVal enabledColor As Long)
    On Error Resume Next
    Dim button As Object
    Set button = ws.Shapes("gate_" & macroName)
    If button Is Nothing Then Exit Sub

    If isEnabled Then
        button.OnAction = "'" & ThisWorkbook.Name & "'!" & macroName
        button.Fill.ForeColor.RGB = enabledColor
        button.AlternativeText = ""
    Else
        button.OnAction = ""
        button.Fill.ForeColor.RGB = RGB(174, 184, 193)
        button.AlternativeText = "�ǂݎ���p�̂��߁A���̑���͗��p�ł��܂���B"
    End If
    button.Line.Visible = 0
    button.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
    On Error GoTo 0
End Sub

Private Sub GateUpdateLatestCard(ByVal target As Object)
    Dim revision As Long
    Dim savedAt As Variant
    Dim author As String
    If GateGetSuccessHistory(1, revision, savedAt, author) Then
        target.Value2 = "revision " & revision & vbLf & vbLf & _
                        "�����ۑ������F" & Format$(savedAt, "yyyy/mm/dd hh:nn") & vbLf & _
                        "�ۑ��ҁ@�F" & author
    Else
        target.Value2 = "�����ۑ��̋L�^�͂���܂���"
    End If
End Sub

Private Function GateGetSuccessHistory(ByVal successNumber As Long, ByRef revision As Long, ByRef savedAt As Variant, ByRef author As String) As Boolean
    Dim ws As Object
    Set ws = ThisWorkbook.Worksheets(GATE_HISTORY_SHEET)
    Dim found As Long
    Dim rowNumber As Long
    For rowNumber = ws.Cells(ws.Rows.Count, 1).End(-4162).Row To 2 Step -1
        If CStr(ws.Cells(rowNumber, 7).Value2) = "SUCCESS" Then
            found = found + 1
            If found = successNumber Then
                revision = CLng(Val(CStr(ws.Cells(rowNumber, 1).Value2)))
                savedAt = ws.Cells(rowNumber, 2).Value
                author = CStr(ws.Cells(rowNumber, 3).Value2)
                GateGetSuccessHistory = True
                Exit Function
            End If
        End If
    Next rowNumber
End Function

Private Function GateDisplayDateTime(ByVal storedText As String) As String
    GateDisplayDateTime = GateFormatDateTimeValue(storedText, "yyyy/mm/dd hh:nn")
End Function

Private Function GateElapsedText(ByVal startText As String, ByVal endValue As Date) As String
    Dim startValue As Date
    If Not GateTryDateTime(startText, startValue) Then
        GateElapsedText = "�s��"
        Exit Function
    End If
    Dim minutes As Long
    minutes = DateDiff("n", startValue, endValue)
    If minutes < 0 Then
        GateElapsedText = "PC�������m�F���Ă�������"
    ElseIf minutes < 60 Then
        GateElapsedText = minutes & "��"
    ElseIf minutes < 1440 Then
        GateElapsedText = (minutes \ 60) & "����" & (minutes Mod 60) & "��"
    Else
        GateElapsedText = (minutes \ 1440) & "��" & ((minutes Mod 1440) \ 60) & "����"
    End If
End Function

Public Sub GateScheduleTimer()
    If gImportInProgress Or gTimerScheduled Or Not gTimerSupported Then Exit Sub
    On Error GoTo TimerUnavailable
    gNextTimerAt = Now + TimeSerial(0, 1, 0)
    Application.OnTime EarliestTime:=gNextTimerAt, Procedure:="'" & ThisWorkbook.Name & "'!GateTimerTick", Schedule:=True
    gTimerScheduled = True
    Exit Sub
TimerUnavailable:
    gTimerSupported = False
    gTimerScheduled = False
End Sub

Public Sub GateCancelTimer()
    If Not gTimerScheduled Then Exit Sub
    On Error Resume Next
    Application.OnTime EarliestTime:=gNextTimerAt, Procedure:="'" & ThisWorkbook.Name & "'!GateTimerTick", Schedule:=False
    On Error GoTo 0
    gTimerScheduled = False
End Sub

Public Sub GateTimerTick()
    gTimerScheduled = False
    If gImportInProgress Or gClosingApproved Then Exit Sub
    RefreshOperationPanel
    GateScheduleTimer
End Sub
